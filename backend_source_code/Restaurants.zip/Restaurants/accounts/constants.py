ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('owner', 'Owner'),
        ('chef', 'Chef'),
        ('staff', 'Staff'),
        ('customer', 'Customer'),
)


ACTION_CHOICES = [
    ('active', 'Active'),
    ('hold', 'Hold'),
]