STATUS =(
    ('pending', 'Pending'),
    ('preparing', 'Preparing'),
    ('served', 'Served'),
    ('paid', 'Paid'),
    ('cancelled', 'Cancelled'),
    ('completed', 'Completed'),
)


PAYMENT_STATUS = [
    ('unpaid', 'Unpaid'),
    ('paid', 'Paid'),
]