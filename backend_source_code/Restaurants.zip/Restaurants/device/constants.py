ACTION_CHOICES = [
        ('active', 'Active'),
        ('hold', 'Hold'),
]


STATUS_CHOICES = [
        ('accept', 'Accepted'),
        ('hold', 'Hold'),
        ('cancel', 'Cancelled'),
]